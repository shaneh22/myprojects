givenSizeSmall(6,15,10).
givenSizeMedium(13,30,30).
givenSizeLarge(27,120,50).
givenSizes(Distance, Duration, ExhalationLevel) :- 
	givenSizeSmall(Distance,Duration,ExhalationLevel);
	givenSizeMedium(Distance,Duration,ExhalationLevel);
	givenSizeLarge(Distance,Duration,ExhalationLevel).

safeDistanceSmall(6). 
safeDistanceMedium(13). 
safeDistanceLarge(27).
safeDurationSmall(15). 
safeDurationMedium(30). 
safeDurationLarge(120). 
safeExhalationLevelSmall(10). 
safeExhalationLevelMedium(30). 
safeExhalationLevelLarge(50). 

givenSafe(Distance, Duration, ExhalationLevel) :-
	givenSizeMedium(Distance, Duration, ExhalationLevel);
	safeDistanceSmall(Distance),safeDurationMedium(Duration),safeExhalationLevelSmall(ExhalationLevel);
	safeDistanceLarge(Distance),safeDurationMedium(Duration),safeExhalationLevelLarge(ExhalationLevel);
	safeDistanceMedium(Distance),safeDurationSmall(Duration),safeExhalationLevelLarge(ExhalationLevel);
	safeDistanceMedium(Distance),safeDurationLarge(Duration),safeExhalationLevelSmall(ExhalationLevel);
	safeDistanceLarge(Distance),safeDurationLarge(Duration),safeExhalationLevelMedium(ExhalationLevel);
	safeDistanceSmall(Distance),safeDurationSmall(Duration),safeExhalationLevelMedium(ExhalationLevel).
%Consider the three smaller problems of determining if a distance, duration, or exhalation level is safer than a given distance, duration and exhalation level.
isDistanceSafer(SafeDistance, InputtedDistance) :-
	SafeDistance =< InputtedDistance.
%Consider the three smaller problems of determining if a distance, duration, or exhalation level is safer than a given distance, duration and exhalation level.
isDurationSafer(SafeDuration, InputtedDuration) :-
	SafeDuration >= InputtedDuration. 
%Consider the three smaller problems of determining if a distance, duration, or exhalation level is safer than a given distance, duration and exhalation level.
isExhalationLevelSafer(SafeExhalationLevel, InputtedExhalationLevel) :-
	SafeExhalationLevel >= InputtedExhalationLevel.
derivedSafe(Distance, Duration, ExhalationLevel) :-
	safeDistanceMedium(MediumDistance),isDistanceSafer(MediumDistance,Distance),safeDurationMedium(MediumDuration),isDurationSafer(MediumDuration,Duration),safeExhalationLevelMedium(MediumExhalation),isExhalationLevelSafer(MediumExhalation, ExhalationLevel);
	safeDistanceSmall(SmallDistance),isDistanceSafer(SmallDistance,Distance),safeDurationMedium(MediumDuration),isDurationSafer(MediumDuration,Duration),safeExhalationLevelSmall(SmallExhalation),isExhalationLevelSafer(SmallExhalation, ExhalationLevel);
	safeDistanceLarge(LargeDistance),isDistanceSafer(LargeDistance,Distance),safeDurationMedium(MediumDuration),isDurationSafer(MediumDuration,Duration),safeExhalationLevelLarge(LargeExhalation),isExhalationLevelSafer(LargeExhalation, ExhalationLevel);
	safeDistanceMedium(MediumDistance),isDistanceSafer(MediumDistance,Distance),safeDurationSmall(SmallDuration),isDurationSafer(SmallDuration,Duration),safeExhalationLevelLarge(LargeExhalation),isExhalationLevelSafer(LargeExhalation, ExhalationLevel);
	safeDistanceMedium(MediumDistance),isDistanceSafer(MediumDistance,Distance),safeDurationLarge(LargeDuration),isDurationSafer(LargeDuration,Duration),safeExhalationLevelSmall(SmallExhalation),isExhalationLevelSafer(SmallExhalation, ExhalationLevel);
	safeDistanceLarge(LargeDistance),isDistanceSafer(LargeDistance,Distance),safeDurationLarge(LargeDuration),isDurationSafer(LargeDuration,Duration),safeExhalationLevelMedium(MediumExhalation),isExhalationLevelSafer(MediumExhalation, ExhalationLevel);
	safeDistanceSmall(SmallDistance),isDistanceSafer(SmallDistance,Distance),safeDurationSmall(SmallDuration), isDurationSafer(SmallDuration,Duration),safeExhalationLevelMedium(MediumExhalation),isExhalationLevelSafer(MediumExhalation, ExhalationLevel).

integerMax(200).
leastDistance(0).

interpolatedDistance(Distance, InterpolatedDistance) :-
	safeDistanceSmall(SmallDistance), Distance < SmallDistance,
	leastDistance(DistanceMinimum), InterpolatedDistance = DistanceMinimum;
	safeDistanceMedium(MediumDistance), safeDistanceSmall(SmallDistance), 
	Distance >= SmallDistance, Distance < MediumDistance, InterpolatedDistance = SmallDistance;
	safeDistanceMedium(MediumDistance), safeDistanceLarge(LargeDistance),
	Distance >= MediumDistance, Distance < LargeDistance, InterpolatedDistance = MediumDistance;
	safeDistanceLarge(LargeDistance), Distance >= LargeDistance, InterpolatedDistance = LargeDistance.

interpolatedSafe(Distance) :-
	interpolatedDistance(Distance, InterpolatedDistance),
	safeDurationMedium(MediumDuration),
	safeExhalationLevelMedium(MediumExhalation),
	givenSafe(InterpolatedDistance,MediumDuration,MediumExhalation).	
	
interpolatedDuration(Duration, InterpolatedDuration) :-
	safeDurationSmall(SmallDuration), Duration =< SmallDuration, InterpolatedDuration = SmallDuration;
	safeDurationSmall(SmallDuration), safeDurationMedium(MediumDuration),
	Duration > SmallDuration, Duration =< MediumDuration, InterpolatedDuration = MediumDuration;
	safeDurationMedium(MediumDuration), safeDurationLarge(LargeDuration), 
	Duration > MediumDuration, Duration =< LargeDuration, InterpolatedDuration = LargeDuration;
	safeDurationLarge(LargeDuration), integerMax(DurationMax),
	Duration > LargeDuration, InterpolatedDuration = DurationMax.
	
interpolatedSafe(Distance, Duration) :-
	interpolatedDistance(Distance, InterpolatedDistance),
	interpolatedDuration(Duration, InterpolatedDuration),
	safeExhalationLevelMedium(MediumExhalation),
	givenSafe(InterpolatedDistance,InterpolatedDuration,MediumExhalation).	
	
interpolatedExhalationLevel(ExhalationLevel, InterpolatedExhalationLevel) :-
	safeExhalationLevelSmall(SmallExhalationLevel), ExhalationLevel =< SmallExhalationLevel, InterpolatedExhalationLevel = SmallExhalationLevel;
	safeExhalationLevelSmall(SmallExhalationLevel), safeExhalationLevelMedium(MediumExhalationLevel),
	ExhalationLevel > SmallExhalationLevel, ExhalationLevel =< MediumExhalationLevel, InterpolatedExhalationLevel = MediumExhalationLevel;
	safeExhalationLevelMedium(MediumExhalationLevel), safeExhalationLevelLarge(LargeExhalationLevel), 
	ExhalationLevel > MediumExhalationLevel, ExhalationLevel =< LargeExhalationLevel, InterpolatedExhalationLevel = LargeExhalationLevel;
	safeExhalationLevelLarge(LargeExhalationLevel), integerMax(ExhalationLevelMax),
	ExhalationLevel > LargeExhalationLevel, InterpolatedExhalationLevel = ExhalationLevelMax.
	
interpolatedSafe(Distance, Duration, ExhalationLevel) :-
	interpolatedDistance(Distance, InterpolatedDistance),
	interpolatedDuration(Duration, InterpolatedDuration),
	interpolatedExhalationLevel(ExhalationLevel, InterpolatedExhalationLevel),
	givenSafe(InterpolatedDistance,InterpolatedDuration, InterpolatedExhalationLevel).		
	
generateSafeDistancesAndDurations(Distance, Duration, ExhalationLevel) :-
	interpolatedExhalationLevel(ExhalationLevel, InterpolatedExhalationLevel),
	givenSafe(SafeDistance, SafeDuration, InterpolatedExhalationLevel),
	Distance = SafeDistance, Duration = SafeDuration.
	
safeCombinations([[13,30,30],[6,30,10],[27,30,50],[13,15,50],[13,120,10],[27,120,30],[6,15,30]]).
givenHeader("Distance, Duration, Exhalation, IsSafe").
printGivenCombinations(Number) :-
	givenHeader(Header), write(Header), nl, safeCombinations(SafeCombinations), printGivenCombinations(Number, SafeCombinations).
printGivenCombinations(0,[]).
printGivenCombinations(Number, [[Distance, Duration, ExhalationLevel] | Tail]) :-
	Number > 0, write(Distance), write(","), write(Duration), write(","), write(ExhalationLevel), write(",true"), nl, printGivenCombinations(Number-1,Tail).
listGivenSafe([Distance, Duration, ExhalationLevel]) :-
	safeCombinations(SafeCombinations), listGivenSafe([Distance, Duration, ExhalationLevel], SafeCombinations).	
listGivenSafe([Distance, Duration, ExhalationLevel], [[SafeDistance, SafeDuration, SafeExhalationLevel] | Tail]) :-
	Distance = SafeDistance, Duration = SafeDuration, ExhalationLevel = SafeExhalationLevel; Tail \= [], listGivenSafe([Distance, Duration, ExhalationLevel], Tail).

listGenerateSafeDistancesAndDurations(ExhalationLevel, GeneratedTable) :-
	safeCombinations(SafeCombinations), interpolatedExhalationLevel(ExhalationLevel, InterpolatedExhalationLevel), listGenerateSafeDistancesAndDurations(InterpolatedExhalationLevel, [], GeneratedTable, SafeCombinations).
listGenerateSafeDistancesAndDurations(ExhalationLevel, TableToBeAppended, GeneratedTable, []) :-
	GeneratedTable = TableToBeAppended; ExhalationLevel = [].
listGenerateSafeDistancesAndDurations(ExhalationLevel, TableToBeAppended, GeneratedTable, [[SafeDistance, SafeDuration, SafeExhalationLevel] | Tail]) :-
	(
		(
		  ExhalationLevel = SafeExhalationLevel,
		  append(TableToBeAppended, [[SafeDistance, SafeDuration]], AppendedTable)
		);
		( ExhalationLevel \= SafeExhalationLevel, AppendedTable = TableToBeAppended, true)
	),
	listGenerateSafeDistancesAndDurations(ExhalationLevel, AppendedTable, GeneratedTable, Tail).
	
	
	
	
append([], ListToBeAppended, ListToBeAppended). 
append([Head|Tail], ListToBeAppended, [Head|AppendedTail]) :-
	append(Tail, ListToBeAppended, AppendedTail).	



	
	