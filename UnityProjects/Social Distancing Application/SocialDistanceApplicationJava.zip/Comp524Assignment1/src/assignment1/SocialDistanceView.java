package assignment1;

import java.beans.PropertyChangeListener;

public interface SocialDistanceView extends PropertyChangeListener{
	static final String SAFE = "Safe.";
	static final String NOT_SAFE = "Not Safe!";
}
